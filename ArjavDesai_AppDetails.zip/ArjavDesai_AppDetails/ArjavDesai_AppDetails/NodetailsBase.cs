﻿namespace ArjavDesai_AppDetails
{
    public class NodetailsBase
    {
    }
}