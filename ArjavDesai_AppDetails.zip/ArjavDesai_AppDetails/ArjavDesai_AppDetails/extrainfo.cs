﻿using System;

namespace ArjavDesai_AppDetails
{
    internal class extrainfo
    {
        public class Extrainfo : app_options
        {

            public void press_any_key()
            {
                Console.WriteLine("");
                Console.WriteLine("Press any key continue....");
                Console.ReadLine();
                Console.ResetColor();
            }

            public void invalid_option()
            {

                Console.WriteLine("Sorry! your option is not valid, please enter option between 1 and 3 ");
                Console.ResetColor();
            }
        }

        internal void press_any_key()
        {
            throw new NotImplementedException();
        }

        internal void invalid_option()
        {
            throw new NotImplementedException();
        }
    }
}
    