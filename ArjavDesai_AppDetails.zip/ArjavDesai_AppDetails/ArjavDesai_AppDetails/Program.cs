﻿using System;
using System.Collections.Generic;

namespace ArjavDesai_AppDetails
{
    class Program
    {
        public class Application            
        {
            private static object show_app_info;

            private static void Main(string[] args)
            {
                Appinfo D1 = new Appinfo();
                Nodetails D2 = new Nodetails();
                extrainfo D3 = new extrainfo();

                var app_info = new List<app_options>();

                while (true)
                {
                   
                    D1.Introduction();
                    D1.menu_list();
                    Console.Write("Enter your option: ");
                    int option = Convert.ToInt32(Console.ReadLine());
                    Console.ResetColor();

                    if (option == 1)
                    {
                        Console.Clear();
                        Console.WriteLine("Add new application information");
                        Console.WriteLine("");

                        Console.Write("Application name: ");
                        var app_name = Console.ReadLine();
                        Console.Write("Developer name: ");
                        var developer_name = Console.ReadLine();
                        Console.Write("Programming Language: ");
                        var programming_language = Console.ReadLine();
                        Console.Write("Foundation Year: ");
                        var foundation_year = Convert.ToDateTime(Console.ReadLine());
                        Console.Write("URL: ");
                        var url = Console.ReadLine();

                        app_info.Add(new app_options(app_name, developer_name, programming_language, foundation_year, url));

                        D3.press_any_key();

                    }

                    else if (option == 2)
                    {
                        Console.Clear();
                        Console.WriteLine("List all the application infromation");
                        Console.WriteLine("");
                        Console.ResetColor();

                        if (app_info.Count > 0)
                        {
                            foreach (var show_app_info in app_info)
                            {
                                Console.WriteLine($"App name: {show_app_info.App_name}");
                                Console.WriteLine($"Developer name: {show_app_info.Developer_name}");
                                Console.WriteLine($"Programming Language: {show_app_info.Programming_language}");
                                Console.WriteLine($"Foundation Year: {show_app_info.Foundation_year}");
                                Console.WriteLine($"URL: {show_app_info.Url}");
                            }
                        }

                        else
                        {

                            D2.No_details();
                        }

                        D3.press_any_key();

                        Console.WriteLine("");
                    }

                    else if (option == 3)
                    {
                        break;
                    }

                    else
                    {

                        D3.invalid_option();
                    }
                }
            }
        }
    }
}

