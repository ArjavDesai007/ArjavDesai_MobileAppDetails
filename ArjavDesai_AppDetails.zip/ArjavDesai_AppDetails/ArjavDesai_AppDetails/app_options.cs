﻿using System;

namespace ArjavDesai_AppDetails
{
    internal class app_options
    {
        internal readonly object App_name;
        internal readonly object Developer_name;
        internal readonly object Programming_language;
        internal readonly object Foundation_year;
        internal readonly object Url;
        private string app_name;
        private string developer_name;
        private string programming_language;
        private DateTime foundation_year;
        private string url;

        public app_options()
        {
        }

        public app_options(string app_name, string developer_name, string programming_language, DateTime foundation_year, string url)
        {
            this.app_name = app_name;
            this.developer_name = developer_name;
            this.programming_language = programming_language;
            this.foundation_year = foundation_year;
            this.url = url;
        }
    }
}