﻿using System;

namespace ArjavDesai_AppDetails
{
    public class Appinfo : app_options
    {
        public Appinfo() : base()
        { }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public void Introduction()
        {
            Console.Clear();
            Console.WriteLine("Application Info Database ");
            Console.WriteLine("");

            Console.WriteLine("Please choose any option you want");
            Console.WriteLine("");
        }

     
        public void menu_list()
        {
            Console.WriteLine("option 1 : Add new application information");
            Console.WriteLine("Option 2 : List all the application infromation");
            Console.WriteLine("Option 3 : Exit");
            Console.WriteLine("");
            Console.ResetColor();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}