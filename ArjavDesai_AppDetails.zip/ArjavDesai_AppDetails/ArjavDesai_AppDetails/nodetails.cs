﻿using System;

namespace ArjavDesai_AppDetails
{
    public class Nodetails : app_options
    {
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public void No_details()
        {
            Console.WriteLine("Sorry you didn't enter website details");
            Console.ResetColor();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}